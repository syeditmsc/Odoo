from odoo import fields, models


class HolidaysRequest(models.Model):
    _inherit = 'hr.leave'

    """
    To make the name field (Description) in Time off Mandatory
    """
    name = fields.Char(required=True)
