from odoo import models, api


class Users(models.Model):
    _inherit = 'res.users'

    # [FIX] the unnecessary groups attachment issue with user by create user from employee
    def _default_groups(self):
        """Default groups for employees

        All the groups of the Template User excluding Invoice Billing and full accounting feature and including Stage.creation.restriction
        """
        # Check context key to see if custom functionality should apply
        if self.env.context.get('user_create_from_emp'):
            super(Users, self)._default_groups()
            default_user = self.env.ref('base.default_user', raise_if_not_found=False)
            groups = default_user.sudo().groups_id
            # getting all the groups to be added or remove from the user
            stage_create_restrict_grp = self.env['res.groups'].search([('name', '=', 'Stage.creation.restriction')])
            billing_grp = self.env.ref('account.group_account_invoice')
            full_accounting_feature_grp = self.env.ref('account.group_account_user')
            # refining the groups
            refined_groups = groups - billing_grp - full_accounting_feature_grp + stage_create_restrict_grp
            return refined_groups
        else:
            # dealing with if the request was not from the employee model
            super(Users, self)._default_groups()

    @api.model
    def write(self, values):
        """ write function to remove unnecessary groups from employees

        only deal with those request comming from employee model to create the user
        """

        # Check context key to see if custom functionality should apply
        if self.env.context.get('user_create_from_emp'):
            # getting invoice billing group
            billing_grp = self.env.ref('account.group_account_invoice')
            # getting show full accounting group
            full_accounting_feature_grp = self.env.ref('account.group_account_user')
            # organizing the values to delete to give them in query
            grp_ids_to_dlt = (billing_grp.id, full_accounting_feature_grp.id)
            # check for user in self
            for user in self:
                # Execute a SQL query to delete the record directly from the database
                self.env.cr.execute("""
                                    DELETE FROM res_groups_users_rel
                                    WHERE uid = %s AND gid IN %s
                                """, (user.id, grp_ids_to_dlt))

        # Default behavior if request is not from employee model
        return super(Users, self).write(values)
