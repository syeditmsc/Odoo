from odoo import models, fields, api
import logging
from lxml import etree

_logger = logging.getLogger(__name__)


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    is_intern = fields.Boolean(string='Is Intern')
    is_lead = fields.Boolean(string='Is Team Lead')
    other_email = fields.Char(string='Other Email')
    message_main_attachment_id = fields.Many2one()


    """
    To add the employee with User account in the Intern Group.
    """
    @api.onchange('is_intern')
    def _onchange_is_intern(self):
        intern_group = self.env.ref('hq17_customization.group_intern_group')
        for employee in self:
            if employee.user_id:
                if employee.is_intern:
                    employee.user_id.write({'groups_id': [(4, intern_group.id)]})
                else:
                    employee.user_id.write({'groups_id': [(3, intern_group.id)]})
                # Keep the checkbox value unchanged
                employee.is_intern = not employee.is_intern

    # [FIX] the unnecessary groups attachment issue with user by create user from employee (adding context to indicate action)
    def action_create_user(self):
        """
        Defining the function to add a context to give indication to the action that whether the request is from
        employee model or other
        """
        self.ensure_one()
        action = super(HrEmployee, self).action_create_user()
        # adding the indicator in the context
        action['context'].update({
            'user_create_from_emp': True
        })
        return action

