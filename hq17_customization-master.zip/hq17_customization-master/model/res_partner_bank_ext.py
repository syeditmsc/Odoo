from odoo import fields, models


class ResPartnerBank(models.Model):
    """
    Inherits the res.partner.bank model to add custom fields related to
    banking and financial institution details, such as SWIFT code and
    transit numbers.

    Adds fields for:
    - SWIFT code
    - Institution number
    - Transit number
    - Branch code
    - Branch address
    - Country (related to the company)
    """

    _inherit = "res.partner.bank"

    # Custom fields for bank details
    swift_code = fields.Char(string="Swift Code")
    institution_number = fields.Char(string="Institution Number")
    transit_number = fields.Char(string="Transit Number")
    branch_code = fields.Char(string="Branch Code")
    branch_address = fields.Char(string="Branch Address")
    routing_number = fields.Char(string="Routing Number (ABA)")
    account_type = fields.Char(string="Account Type")
    country_id = fields.Many2one(
        "res.country", string="Country", related="company_id.country_id", readonly=True
    )


class ProjectProject(models.Model):
    """
    Inherits the project.project model to introduce a team lead relationship.

    Adds:
    - team_lead_id: A Many2one reference to an HR employee who acts as the
      team lead for the project. Limited to employees marked with 'is_lead = True'.
    """

    _inherit = "project.project"

    team_lead_id = fields.Many2one(
        "hr.employee",
        string="Team Lead",
        required=False,
        domain=[("is_lead", "=", True)],
    )
