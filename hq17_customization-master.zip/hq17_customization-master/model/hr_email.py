# from datetime import datetime, timedelta
# from odoo import models, fields, api
# from dateutil.relativedelta import relativedelta
#
#
# class CustomModel(models.Model):
#     _name = 'custom.model'
#
#     @api.model
#     def send_leave_reminder_emails(self):
#         last_month_start = (datetime.now() - relativedelta(months=1)).replace(day=1)
#         last_month_end = last_month_start + relativedelta(day=31)
#
#         last_month_name = last_month_start.strftime('%B')
#
#         employees = self.env['hr.employee'].search([])
#         template = self.env.ref('hq17_customization.attendance_mail_hq1')
#
#         for employee in employees:
#             leaves = self.env['hr.leave'].search([
#                 ('employee_id', '=', employee.id),
#                 ('request_date_from', '>=', last_month_start),
#                 ('request_date_to', '<=', last_month_end)
#             ])
#             remaining_leaves = employee.remaining_leaves
#
#             email_content = template.body_html
#             email_content = email_content.replace('{{ object.partner_email }}', employee.work_email)
#             email_content = email_content.replace('(Month)', last_month_start.strftime('%B'))
#             email_content = email_content.replace('(Month)', last_month_name)
#
#             leaves_availed = sum((leave.request_date_to - leave.request_date_from).days + 1 for leave in leaves)
#             email_content = email_content.replace('Leaves Availed:', 'Leaves Availed:\n{}'.format(leaves_availed))
#
#             email_content = email_content.replace('Leaves Balance:', 'Leaves Balance: {}'.format(remaining_leaves))
#
#             mail_values = {
#                 'subject': template.subject,
#                 'body_html': email_content,
#                 'email_to': employee.work_email,
#                 'email_from': template.email_from,
#             }
#             self.env['mail.mail'].create(mail_values).send()
#
#         return True
#


"""

    Model for the automated email  for Time off module
    To send Leave Balance email to all employees

"""