from odoo import models
from odoo.addons.payment_stripe.controllers.main import StripeController
from werkzeug.urls import url_encode, url_join


class PaymentTransaction(models.Model):
    _inherit = 'payment.transaction'

    def _get_specific_processing_values(self, processing_values):
        res = super()._get_specific_processing_values(processing_values)
        if self.provider_code != 'stripe' or self.operation == 'online_token':
            return res

        intent = self._stripe_create_intent()
        base_url_parm = self.env['ir.config_parameter'].search([('key', '=', 'base_url')])
        if base_url_parm:
            base_url = base_url_parm.value
        else:
            base_url = self.provider_id.get_base_url()

        return {
            'client_secret': intent['client_secret'],
            'return_url': url_join(
                base_url,
                f'{StripeController._return_url}?{url_encode({"reference": self.reference})}',
            ),
        }
