from odoo import models, fields, api
import logging
from lxml import etree

_logger = logging.getLogger(__name__)


class LinkTrackerClick(models.Model):
    _inherit = "link.tracker.click"

    tracked_email = fields.Char('Clicked BY', compute="compute_clicked_by")


    @api.depends('mailing_trace_id')

    def compute_clicked_by(self):
        for temp in self:
            temp.tracked_email = temp.mailing_trace_id.email

