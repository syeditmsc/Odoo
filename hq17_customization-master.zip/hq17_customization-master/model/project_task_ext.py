from odoo import fields, models, api, _


class ProjectTask(models.Model):
    _inherit = "project.task"
    """
    To make the deadline field  in Time off Mandatory
    """
    stage_name = fields.Char(
        string="Stage Name", compute="_compute_stage_name", store=True
    )

    task_type = fields.Selection(
        [
            ("bugs", "Bugs"),
            ("rework", "Rework"),
            ("error", "Error"),
        ],
        string="Task Type",
        tracking=True,
    )

    @api.depends("stage_id")
    def _compute_stage_name(self):
        """
        Compute the display name of the current stage and store it in the `stage_name` field.

        This method is triggered whenever the `stage_id` changes. It assigns the
        human-readable name of the stage (`display_name`) to a computed field
        (`stage_name`), which can be used for easier referencing or display purposes.
        """
        for task in self:
            task.stage_name = task.stage_id.display_name

    def write(self, vals):
        """
        Override the default write method to log a message in the chatter when the task
        description is changed.

        If the 'description' field is present in the update values and its content differs
        from the current value, a note is posted to the task's chatter indicating that
        the description has changed.

        :param vals: Dictionary of field values to be updated.
        :return: Result of the super call to the original write method.
        """
        for task in self:
            if "description" in vals and task.description != vals["description"]:
                task.message_post(
                    body=_("Description changed."),
                    subtype_xmlid="mail.mt_note",
                )
        return super(ProjectTask, self).write(vals)
