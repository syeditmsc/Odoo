# -*- coding: utf-8 -*-
{
    'name': "HQ17 Customization",  # Module title
    'summary': "",  # Module subtitle phrase
    'author': "umer",
    'website': 'https://www.axiomworld.net/',
    'category': 'Uncategorized',
    # 'version': '12.0.1',
    'depends': ['hr','hr_holidays','account', 'l10n_ca'],
    'data': [

        'security/security_groups.xml',
        'security/ir.model.access.csv',
        'views/hr_employee_views.xml',
        'views/link_tracker_click.xml',
        'views/project_task_ext.xml',
        'views/res_partner_bank_ext.xml',
        'reports/account_move_invoice_ext.xml',
        # 'data/scheduler_attendance_mail.xml',
        # 'data/attendance_mail.xml',

    ],
    # This demo data files will be loaded if db initialize with demo data (commented becaues file is not added in this example)
    # 'demo': [
    #     'demo.xml'
    # ],
}
