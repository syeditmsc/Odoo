

# Configuration file for Sphinx documentation builder



project = 'Odoo Modules Documentation'

copyright = '2024, Your Company'

author = 'Your Name'



# General configuration

extensions = [

    'sphinx.ext.napoleon',

    'sphinx.ext.autodoc',

    'sphinx.ext.viewcode',

    'sphinx_rtd_theme',

    'sphinxcontrib.httpdomain',  # For API documentation

]



# The suffix of source filenames

source_suffix = '.rst'



# The master toctree document

master_doc = 'index'



# List of patterns to exclude from package

exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store']



# The name of the Pygments (syntax highlighting) style to use

pygments_style = 'sphinx'



# Theme configuration

html_theme = 'sphinx_rtd_theme'

html_theme_options = {

    'navigation_depth': 4,

    'collapse_navigation': False,

    'sticky_navigation': True,

    'includehidden': True,

    'titles_only': False

}



# Static files

html_static_path = ['_static']



# Custom sidebar templates

html_sidebars = {

    '**': [

        'relations.html',

        'searchbox.html',

        'navigation.html',

    ]

}



# Output options

html_show_sourcelink = False

html_show_sphinx = False

