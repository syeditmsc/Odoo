

Welcome to Odoo Modules Documentation

===================================



This documentation covers the technical details of the current Odoo module.



Contents

--------



.. toctree::

    :maxdepth: 2

    :caption: Module Components:



   hq17_customization_index
