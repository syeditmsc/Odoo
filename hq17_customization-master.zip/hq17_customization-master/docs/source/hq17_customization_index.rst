

hq17_customization

==================







Module Information

-----------------



* **Version:** N/A

* **Category:** Uncategorized

* **Author:** umer

* **Website:** https://www.axiomworld.net/

* **Depends:** hr, hr_holidays, account, l10n_ca



Module Components

----------------



.. toctree::

    :maxdepth: 2



    hq17_customization/models

    hq17_customization/controllers

    hq17_customization/wizards

    hq17_customization/api

